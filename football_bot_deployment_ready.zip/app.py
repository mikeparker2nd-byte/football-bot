import os
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo
import requests
from flask import Flask, jsonify, request, send_from_directory

API_BASE = "https://api.football-data.org/v4"
TOKEN = os.getenv("FOOTBALL_DATA_API_KEY")
TZ = ZoneInfo("Africa/Lagos")

app = Flask(__name__, static_folder="web")

def api_get(path="", params=None):
    if not TOKEN:
        return {"error": "Football API key has not been configured on the server."}
    try:
        r = requests.get(
            API_BASE + path,
            headers={"X-Auth-Token": TOKEN},
            params={k: v for k, v in (params or {}).items() if v not in (None, "")},
            timeout=20,
        )
        try:
            data = r.json()
        except Exception:
            data = {"error": r.text or f"Provider HTTP {r.status_code}"}
        if not r.ok:
            return {"error": data.get("message", f"Provider HTTP {r.status_code}"),
                    "status": r.status_code}
        return data
    except requests.RequestException as e:
        return {"error": f"Could not reach football-data.org: {e}"}

def normalize(data):
    if isinstance(data, dict) and "matches" in data:
        for m in data["matches"]:
            if m.get("utcDate"):
                try:
                    dt = datetime.fromisoformat(m["utcDate"].replace("Z", "+00:00")).astimezone(TZ)
                    m["kickoffLagos"] = dt.strftime("%a %d %b %Y, %H:%M")
                except Exception:
                    pass
    return data

@app.get("/")
def index():
    return send_from_directory("web", "index.html")

@app.get("/api/health")
def health():
    return jsonify({"ok": bool(TOKEN), "provider": "football-data.org", "timezone": "Africa/Lagos"})

@app.get("/api/competitions")
def competitions():
    return jsonify(api_get("/competitions"))

@app.get("/api/today")
def today():
    d = datetime.now(TZ).date()
    return jsonify(normalize(api_get("/matches", {"dateFrom": str(d), "dateTo": str(d)})))

@app.get("/api/live")
def live():
    return jsonify(normalize(api_get("/matches", {"status": "LIVE"})))

@app.get("/api/fixtures")
def fixtures():
    d = request.args.get("date")
    start = request.args.get("from") or d
    end = request.args.get("to") or d
    return jsonify(normalize(api_get("/matches", {"dateFrom": start, "dateTo": end})))

@app.get("/api/competition/<code>/matches")
def competition_matches(code):
    return jsonify(normalize(api_get(
        f"/competitions/{code}/matches",
        {"dateFrom": request.args.get("from"), "dateTo": request.args.get("to")}
    )))

@app.get("/api/standings/<code>")
def standings(code):
    return jsonify(api_get(f"/competitions/{code}/standings"))

@app.get("/api/team/<int:team_id>")
def team(team_id):
    return jsonify(api_get(f"/teams/{team_id}"))

@app.get("/api/team/<int:team_id>/matches")
def team_matches(team_id):
    return jsonify(normalize(api_get(
        f"/teams/{team_id}/matches",
        {"dateFrom": request.args.get("from"), "dateTo": request.args.get("to")}
    )))

@app.get("/api/search")
def search():
    q = (request.args.get("q") or "").strip().lower()
    if not q:
        return jsonify({"error": "Enter a search term."})
    comps = api_get("/competitions")
    results = []
    for c in comps.get("competitions", []):
        if q in c.get("name", "").lower() or q in c.get("code", "").lower():
            results.append({
                "type": "competition",
                "id": c.get("id"),
                "code": c.get("code"),
                "name": c.get("name")
            })
    return jsonify({"query": q, "results": results})

@app.get("/api/chat")
def chat():
    q = (request.args.get("q") or "").strip().lower()
    if "live" in q:
        return jsonify({"answer": "Here are matches currently returned as LIVE by football-data.org.",
                        "data": normalize(api_get("/matches", {"status": "LIVE"}))})
    if "today" in q:
        d = datetime.now(TZ).date()
        return jsonify({"answer": f"Today's fixtures ({d}) in Africa/Lagos time.",
                        "data": normalize(api_get("/matches", {"dateFrom": str(d), "dateTo": str(d)}))})
    return jsonify({"answer": "Try 'today' or 'live scores', or use Fixtures for a specific date.",
                    "data": {}})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.getenv("PORT", "5000")))
