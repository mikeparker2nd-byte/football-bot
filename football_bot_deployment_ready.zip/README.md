# Football Bot — Deployment Ready

This is a small Flask website that securely keeps the football-data.org API key on the server.

## Deploy
The project is ready for a Python web host. Do NOT put the API key into `web/index.html`.

For a host with environment variables, create:

FOOTBALL_DATA_API_KEY = your new football-data.org API key

Then deploy. The included `render.yaml` and `Dockerfile` provide deployment configuration.

## Local run
1. Create a virtual environment.
2. Install: `pip install -r requirements.txt`
3. Set `FOOTBALL_DATA_API_KEY` in your environment.
4. Run: `python app.py`
5. Open http://localhost:5000

## Security
The API key previously posted in chat should be revoked. Use a fresh key and keep it in the hosting provider's secret/environment-variable settings.
